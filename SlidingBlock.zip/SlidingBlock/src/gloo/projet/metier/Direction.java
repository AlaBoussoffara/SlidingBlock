package gloo.projet.metier;

import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("30722ee0-03f0-4a30-b524-282a5458095a")
public enum Direction {
    HAUT,
    BAS,
    GAUCHE,
    DROITE;
}
