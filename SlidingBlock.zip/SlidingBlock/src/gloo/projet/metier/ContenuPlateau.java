package gloo.projet.metier;


public enum ContenuPlateau {
    CASE,
    MUR,
    SORTIE;
}
